export declare class NgbButtonLabel {
    active: boolean;
    disabled: boolean;
    focused: boolean;
}
